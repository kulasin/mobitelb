<?php defined( 'LS_ROOT_FILE' ) || exit; ?>
<script type="text/html" id="tmpl-downloading-module">
	<div id="ls-loading-modal-window">
		<div class="ls-loader-container" data-message="<?php _e('Downloading Image Editor ...', 'LayerSlider') ?>">
			<div class="ls-loader-logo">
				<div class="ls-loader-element-3"></div>
				<div class="ls-loader-element-2"></div>
				<div class="ls-loader-element-1"></div>
			</div>
		</div>
	</div>
</script>